﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace المحاضره_السابعه_النموذج_الاول
{
    class person
    {
        string firstname;
        public string lastname;
        public void setfirstname(string n)
        {
            firstname = n;
        }
        public string getfirstname() => firstname;
    }
}
