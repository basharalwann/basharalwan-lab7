﻿namespace المحاضره_السابعه_النموذج_الثاني
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btndiv = new System.Windows.Forms.Button();
            this.btnmult = new System.Windows.Forms.Button();
            this.btnsub = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.العملياتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جمعToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.طرحToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ضربToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قسمهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ملفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btndiv
            // 
            this.btndiv.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndiv.Location = new System.Drawing.Point(88, 411);
            this.btndiv.Margin = new System.Windows.Forms.Padding(4);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(478, 48);
            this.btndiv.TabIndex = 8;
            this.btndiv.Text = "قسمه";
            this.btndiv.UseVisualStyleBackColor = true;
            this.btndiv.Click += new System.EventHandler(this.btndiv_Click);
            // 
            // btnmult
            // 
            this.btnmult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmult.Location = new System.Drawing.Point(88, 327);
            this.btnmult.Margin = new System.Windows.Forms.Padding(4);
            this.btnmult.Name = "btnmult";
            this.btnmult.Size = new System.Drawing.Size(478, 56);
            this.btnmult.TabIndex = 7;
            this.btnmult.Text = "ضرب";
            this.btnmult.UseVisualStyleBackColor = true;
            this.btnmult.Click += new System.EventHandler(this.btnmult_Click);
            // 
            // btnsub
            // 
            this.btnsub.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsub.Location = new System.Drawing.Point(64, 234);
            this.btnsub.Margin = new System.Windows.Forms.Padding(4);
            this.btnsub.Name = "btnsub";
            this.btnsub.Size = new System.Drawing.Size(478, 56);
            this.btnsub.TabIndex = 6;
            this.btnsub.Text = "طرح";
            this.btnsub.UseVisualStyleBackColor = true;
            this.btnsub.Click += new System.EventHandler(this.btnsub_Click);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(64, 133);
            this.btnadd.Margin = new System.Windows.Forms.Padding(4);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(478, 61);
            this.btnadd.TabIndex = 5;
            this.btnadd.Text = "جمع";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.العملياتToolStripMenuItem,
            this.ملفToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(686, 35);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // العملياتToolStripMenuItem
            // 
            this.العملياتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.جمعToolStripMenuItem,
            this.طرحToolStripMenuItem,
            this.ضربToolStripMenuItem,
            this.قسمهToolStripMenuItem});
            this.العملياتToolStripMenuItem.Name = "العملياتToolStripMenuItem";
            this.العملياتToolStripMenuItem.Size = new System.Drawing.Size(91, 29);
            this.العملياتToolStripMenuItem.Text = "العمليات";
            // 
            // جمعToolStripMenuItem
            // 
            this.جمعToolStripMenuItem.Name = "جمعToolStripMenuItem";
            this.جمعToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.جمعToolStripMenuItem.Text = "جمع";
            this.جمعToolStripMenuItem.Click += new System.EventHandler(this.جمعToolStripMenuItem_Click);
            // 
            // طرحToolStripMenuItem
            // 
            this.طرحToolStripMenuItem.Name = "طرحToolStripMenuItem";
            this.طرحToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.طرحToolStripMenuItem.Text = "طرح";
            this.طرحToolStripMenuItem.Click += new System.EventHandler(this.طرحToolStripMenuItem_Click);
            // 
            // ضربToolStripMenuItem
            // 
            this.ضربToolStripMenuItem.Name = "ضربToolStripMenuItem";
            this.ضربToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.ضربToolStripMenuItem.Text = "ضرب";
            this.ضربToolStripMenuItem.Click += new System.EventHandler(this.ضربToolStripMenuItem_Click);
            // 
            // قسمهToolStripMenuItem
            // 
            this.قسمهToolStripMenuItem.Name = "قسمهToolStripMenuItem";
            this.قسمهToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.قسمهToolStripMenuItem.Text = "قسمه";
            this.قسمهToolStripMenuItem.Click += new System.EventHandler(this.قسمهToolStripMenuItem_Click);
            // 
            // ملفToolStripMenuItem
            // 
            this.ملفToolStripMenuItem.Name = "ملفToolStripMenuItem";
            this.ملفToolStripMenuItem.Size = new System.Drawing.Size(59, 29);
            this.ملفToolStripMenuItem.Text = "ملف";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 525);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.btnmult);
            this.Controls.Add(this.btnsub);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btnmult;
        private System.Windows.Forms.Button btnsub;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem العملياتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جمعToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem طرحToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ضربToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قسمهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ملفToolStripMenuItem;
    }
}

