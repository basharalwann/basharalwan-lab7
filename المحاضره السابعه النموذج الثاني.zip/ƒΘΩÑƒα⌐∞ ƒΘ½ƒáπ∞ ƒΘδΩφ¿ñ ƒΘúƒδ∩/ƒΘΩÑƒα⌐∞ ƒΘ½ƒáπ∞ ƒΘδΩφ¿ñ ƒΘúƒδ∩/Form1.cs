﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace المحاضره_السابعه_النموذج_الثاني
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        add add1;
        private void btnadd_Click(object sender, EventArgs e)
        {


            if (add1 == null || add1.IsDisposed)
            {
                add1 = new add();
                add1.Show();
            }
            else
            {
                add1.Show();
            }
        }

        private void جمعToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (add1 == null || add1.IsDisposed)
            {
                add1 = new add();
                add1.Show();
            }
            else
            {
                add1.Show();
            }
        }
        sub sub1;
        private void btnsub_Click(object sender, EventArgs e)
        {
            if (sub1 == null || sub1.IsDisposed)
            {
                sub1 = new sub();
                sub1.Show();
            }
            else
            {
                add1.Show();
            }
        }
        mult m1;
        private void btnmult_Click(object sender, EventArgs e)
        {

            if (m1 == null || m1.IsDisposed)
            {
                m1 = new mult();
                m1.Show();
            }
            else
            {
                add1.Show();
            }

        }

        private void طرحToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sub1 == null || sub1.IsDisposed)
            {
                sub1 = new sub();
                sub1.Show();
            }
            else
            {
                add1.Show();
            }

        
    }

        private void ضربToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m1 == null || m1.IsDisposed)
            {
                m1 = new mult();
                m1.Show();
            }
            else
            {
                add1.Show();
            }
        }
        private void قسمهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (d == null || d.IsDisposed)
            {
                d = new div();
                d.Show();
            }
            else
            {
                d.Show();
            }
        }
        div d;
        private void btndiv_Click(object sender, EventArgs e)
        {

            if (d == null || d.IsDisposed)
            {
                d = new div();
                d.Show();
            }
            else
            {
                d.Show();
            }
        }
    }
    }
    


