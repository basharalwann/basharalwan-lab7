﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace المحاضره_السابعه_النموذج_الثاني
{
    public partial class add : Form
    {
        public add()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((num1.Text.Trim() != "") && (num2.Text.Trim() != ""))
            {
                result.Text = Convert.ToString(Convert.ToInt32(num1.Text) +Convert.ToInt32(num2.Text));
            }
            else
                MessageBox.Show("ادخل رقم");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            num1.Clear();
            num2.Clear();
            result.Clear();

        }

        private void num1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar >57) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void num2_TextChanged(object sender, EventArgs e)
        {

        }

        private void num2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                e.Handled = true;
        }
    }
    }

