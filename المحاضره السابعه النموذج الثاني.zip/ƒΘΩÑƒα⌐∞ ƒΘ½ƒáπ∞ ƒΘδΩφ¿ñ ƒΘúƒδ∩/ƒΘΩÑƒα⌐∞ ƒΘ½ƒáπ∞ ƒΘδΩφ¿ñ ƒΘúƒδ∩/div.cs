﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace المحاضره_السابعه_النموذج_الثاني
{
    public partial class div : Form
    {
        public div()
        {
            InitializeComponent();
        }

        private void div_Load(object sender, EventArgs e)
        {

        }

        private void num1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((num1.Text.Trim() != "") && (num2.Text.Trim() != ""))
            {
                if (num2.Text != "0")
                {
                    result.Text = Convert.ToString(Convert.ToDouble(num1.Text) / Convert.ToDouble(num2.Text));
                }
                else
                    MessageBox.Show("can't divided by zero");
            }
            else
                MessageBox.Show("ادخل رقم");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            num1.Clear();
            num2.Clear();
            result.Clear();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void result_TextChanged(object sender, EventArgs e)
        {

        }

        private void num2_TextChanged(object sender, EventArgs e)
        {

        }

        private void num1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
